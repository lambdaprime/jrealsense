**jrealsense** - Java module which allows to interact with Intel RealSense cameras.

# Download

You can download **jrealsense** module with examples from <https://github.com/lambdaprime/jrealsense/releases>

# Documentation

Documentation is available here <http://portal2.atwebpages.com/jrealsense>

# Contributors

lambdaprime <intid@protonmail.com>
