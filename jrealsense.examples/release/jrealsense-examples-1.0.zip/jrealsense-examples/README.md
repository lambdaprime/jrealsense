Java applications which demonstrate how to work with Intel RealSense cameras using jrealsense module.

# Download

You can download **jrealsense** module with examples from <https://github.com/lambdaprime/jrealsense/releases>

# Documentation

Documentation is available here <http://portal2.atwebpages.com/jrealsense>

# Contributors

lambdaprime <intid@protonmail.com>
